class InsufficientFunds(Exception):
    pass

class InvalidAddress(Exception):
    pass